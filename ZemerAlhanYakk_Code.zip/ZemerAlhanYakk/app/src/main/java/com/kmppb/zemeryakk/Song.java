package com.kmppb.zemeryakk;

public class Song {
    private String title;
    private int resourceId;
    private boolean isFavorite;

    public Song(String title, int resourceId) {
        this.title = title;
        this.resourceId = resourceId;
        this.isFavorite = false;
    }

    public String getTitle() { return title; }
    public int getResourceId() { return resourceId; }
    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }
}

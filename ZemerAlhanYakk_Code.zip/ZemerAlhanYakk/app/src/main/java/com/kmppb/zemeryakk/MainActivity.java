package com.kmppb.zemeryakk;

import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private List<Song> songList;
    private int currentIndex = 0;
    private boolean isPlaying = false;

    private ImageView albumCover;
    private TextView songTitle;
    private TextView currentTime;
    private TextView totalTime;
    private SeekBar seekBar;
    private ImageButton btnBack, btnPlay, btnNext, btnFavorite, btnDelete;
    private ImageButton btnRepeat;
    private boolean isRepeat = false;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable updateSeekBar;

    private SharedPreferences prefs;
    private static final String PREFS_NAME = "ZemerPrefs";
    private static final String DELETED_SONGS_KEY = "deleted_songs";
    private static final String FAVORITES_KEY = "favorites";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        initViews();
        loadSongs();
        setupClickListeners();
        loadSong(currentIndex);
    }

    private void initViews() {
        albumCover = findViewById(R.id.albumCover);
        songTitle = findViewById(R.id.songTitle);
        currentTime = findViewById(R.id.currentTime);
        totalTime = findViewById(R.id.totalTime);
        seekBar = findViewById(R.id.seekBar);
        btnBack = findViewById(R.id.btnBack);
        btnPlay = findViewById(R.id.btnPlay);
        btnNext = findViewById(R.id.btnNext);
        btnFavorite = findViewById(R.id.btnFavorite);
        btnDelete = findViewById(R.id.btnDelete);
        btnRepeat = findViewById(R.id.btnRepeat);
    }

    private void loadSongs() {
        Set<String> deletedSongs = prefs.getStringSet(DELETED_SONGS_KEY, new HashSet<>());
        Set<String> favorites = prefs.getStringSet(FAVORITES_KEY, new HashSet<>());

        List<Song> allSongs = new ArrayList<>();
        allSongs.add(new Song("کاٹمے تین", R.raw.song1));
        allSongs.add(new Song("زانان منا کشی دل", R.raw.song2));
        allSongs.add(new Song("لال خان تانا", R.raw.song3));
        allSongs.add(new Song("دلبرک", R.raw.song4));
        allSongs.add(new Song("نا پنا بے تغی زندگی", R.raw.song5));
        allSongs.add(new Song("بلے شنگٹ", R.raw.song6));
        allSongs.add(new Song("البم آئے آں پاناد", R.raw.song7));
        allSongs.add(new Song("کنے آ خنتے بارزاکر", R.raw.song8));

        songList = new ArrayList<>();
        for (Song song : allSongs) {
            if (!deletedSongs.contains(song.getTitle())) {
                song.setFavorite(favorites.contains(song.getTitle()));
                songList.add(song);
            }
        }

        if (songList.isEmpty()) {
            Toast.makeText(this, "تمام گانے حذف ہو گئے", Toast.LENGTH_LONG).show();
        }
    }

    private void loadSong(int index) {
        if (songList.isEmpty()) return;

        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }

        handler.removeCallbacks(updateSeekBar);

        Song song = songList.get(index);
        songTitle.setText(song.getTitle());

        updateFavoriteIcon(song.isFavorite());

        mediaPlayer = MediaPlayer.create(this, song.getResourceId());
        if (mediaPlayer == null) return;

        totalTime.setText(formatTime(mediaPlayer.getDuration()));
        seekBar.setMax(mediaPlayer.getDuration());
        currentTime.setText("0:00");

        mediaPlayer.setOnCompletionListener(mp -> {
            if (isRepeat) {
                mediaPlayer.seekTo(0);
                mediaPlayer.start();
            } else {
                playNext();
            }
        });

        if (isPlaying) {
            mediaPlayer.start();
            btnPlay.setImageResource(android.R.drawable.ic_media_pause);
            startSeekBarUpdate();
        } else {
            btnPlay.setImageResource(android.R.drawable.ic_media_play);
        }
    }

    private void setupClickListeners() {
        btnPlay.setOnClickListener(v -> togglePlay());
        btnNext.setOnClickListener(v -> playNext());
        btnBack.setOnClickListener(v -> playPrev());
        btnFavorite.setOnClickListener(v -> toggleFavorite());
        btnDelete.setOnClickListener(v -> confirmDelete());
        btnRepeat.setOnClickListener(v -> toggleRepeat());

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mediaPlayer != null) {
                    mediaPlayer.seekTo(progress);
                    currentTime.setText(formatTime(progress));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void togglePlay() {
        if (mediaPlayer == null) return;
        if (isPlaying) {
            mediaPlayer.pause();
            isPlaying = false;
            btnPlay.setImageResource(android.R.drawable.ic_media_play);
            handler.removeCallbacks(updateSeekBar);
        } else {
            mediaPlayer.start();
            isPlaying = true;
            btnPlay.setImageResource(android.R.drawable.ic_media_pause);
            startSeekBarUpdate();
        }
    }

    private void playNext() {
        if (songList.isEmpty()) return;
        isPlaying = true;
        currentIndex = (currentIndex + 1) % songList.size();
        loadSong(currentIndex);
    }

    private void playPrev() {
        if (songList.isEmpty()) return;
        isPlaying = true;
        currentIndex = (currentIndex - 1 + songList.size()) % songList.size();
        loadSong(currentIndex);
    }

    private void toggleFavorite() {
        if (songList.isEmpty()) return;
        Song song = songList.get(currentIndex);
        song.setFavorite(!song.isFavorite());
        updateFavoriteIcon(song.isFavorite());
        saveFavorites();
        String msg = song.isFavorite() ? "پسندیدہ میں شامل ہو گیا ♥" : "پسندیدہ سے ہٹا دیا";
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void updateFavoriteIcon(boolean isFavorite) {
        btnFavorite.setImageResource(isFavorite ?
                R.drawable.ic_favorite_filled : R.drawable.ic_favorite_border);
    }

    private void toggleRepeat() {
        isRepeat = !isRepeat;
        btnRepeat.setAlpha(isRepeat ? 1.0f : 0.4f);
        String msg = isRepeat ? "ریپیٹ آن ہے 🔁" : "ریپیٹ آف ہے";
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void confirmDelete() {
        if (songList.isEmpty()) return;
        Song song = songList.get(currentIndex);
        new AlertDialog.Builder(this)
                .setTitle("گانا حذف کریں")
                .setMessage("کیا آپ \"" + song.getTitle() + "\" کو حذف کرنا چاہتے ہیں؟")
                .setPositiveButton("ہاں، حذف کریں", (dialog, which) -> deleteSong())
                .setNegativeButton("نہیں", null)
                .show();
    }

    private void deleteSong() {
        if (songList.isEmpty()) return;
        Song song = songList.get(currentIndex);

        Set<String> deletedSongs = new HashSet<>(prefs.getStringSet(DELETED_SONGS_KEY, new HashSet<>()));
        deletedSongs.add(song.getTitle());
        prefs.edit().putStringSet(DELETED_SONGS_KEY, deletedSongs).apply();

        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        handler.removeCallbacks(updateSeekBar);

        songList.remove(currentIndex);
        Toast.makeText(this, "گانا حذف ہو گیا", Toast.LENGTH_SHORT).show();

        if (songList.isEmpty()) {
            songTitle.setText("کوئی گانا نہیں");
            currentTime.setText("0:00");
            totalTime.setText("0:00");
            seekBar.setProgress(0);
            btnPlay.setImageResource(android.R.drawable.ic_media_play);
            isPlaying = false;
            return;
        }

        if (currentIndex >= songList.size()) {
            currentIndex = 0;
        }
        isPlaying = true;
        loadSong(currentIndex);
    }

    private void saveFavorites() {
        Set<String> favorites = new HashSet<>();
        for (Song s : songList) {
            if (s.isFavorite()) favorites.add(s.getTitle());
        }
        prefs.edit().putStringSet(FAVORITES_KEY, favorites).apply();
    }

    private void startSeekBarUpdate() {
        updateSeekBar = new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && isPlaying) {
                    int pos = mediaPlayer.getCurrentPosition();
                    seekBar.setProgress(pos);
                    currentTime.setText(formatTime(pos));
                    handler.postDelayed(this, 500);
                }
            }
        };
        handler.post(updateSeekBar);
    }

    private String formatTime(int millis) {
        int seconds = (millis / 1000) % 60;
        int minutes = (millis / 1000) / 60;
        return String.format("%d:%02d", minutes, seconds);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateSeekBar);
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
